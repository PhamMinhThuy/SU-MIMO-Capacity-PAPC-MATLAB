%%
%
%Created on Nov 2016
%Updated on Nov 17 2017
%@author: T. M. Pham, R. Farrell, and L.-N. Tran
%Related publication: T. M. Pham, R. Farrell and L. N. Tran, "Low-Complexity Approaches 
%for MIMO Capacity with Per-Antenna Power Constraint," 2017 IEEE 85th Vehicular 
%Technology Conference (VTC Spring), Sydney, Australia, 2017, pp. 1-7.
%Alg1_fp: computing MIMO capacity by fixed point iteration
%Alg2_ao: computing MIMO capacity by alternting optimization


clear all;
%initialization
nt =2;
nr = 4;
SNRdB = 0;
P = 10.^(SNRdB/10);
eps = 1e-6;
CMIMO_Alg1 = 0;
CMIMO_Alg2 = 0;
N_i1 = 0;
N_i2 = 0;
ilim = 1e4;



%load('Sample','H');%load sample
H = (randn(nr, nt) + j*randn(nr, nt))/sqrt(2);

Pv = (P/nt)*eye(nt);%equal power constraint

%Alg1, fixed point
[S1, N_i1, Dg1] = Alg1_fp(H, Pv, eps, ilim);
CMIMO_Alg1 = log2(abs(det(eye(nr) + H*S1*H')));

%Alg2, alternating optimization
[S2, N_i2, Dg2] = Alg2_ao(H, Pv, eps, ilim);
CMIMO_Alg2 = log2(abs(det(eye(nr) + H*S2*H')));



%plot duality
semilogy(0:N_i1-1,Dg1(1:N_i1),'--b',0:N_i2-1,Dg2(1:N_i2),'-k','LineWidth',1.5);
legend('Algorithm 1', 'Algorithm 2','Location','Best');
xlabel('Iteration Index','FontSize',12,'FontWeight','bold');
ylabel('Duality gap','FontSize',12,'FontWeight','bold');
