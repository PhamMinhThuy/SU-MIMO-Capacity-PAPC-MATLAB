function [Q_found, N_iter, D_gap] = Alg2_ao(H, P, eps, ilim)

%initialization
i = 0;
delta = 1 + eps;
[m, n] = size(H);
LD = eye(n) ;
del = zeros(1, ilim);
Q = zeros(n, n);
Phi = eye(n);
IPhi = Phi;
S = eye(m);
alpha = 0;
obj = 0;
[Q R] = qr(H);

while(delta > eps)
    %solve maximization problem
    [UH1 SH1 VH1] = svd(R*diag(diag(LD).^(-1/2)));
    UH = VH1;
    SH = SH1';
    VH = (Q*UH1);
    [power, muy] = wf(P, diag(diag(LD).^(-1/2))*H');
    
    if(rank(diag(diag(LD).^(-1/2))*H') < m)
        power = [power, zeros(1, (m-rank(diag(diag(LD).^(-1/2))*H')))];
    end
    S = VH*diag(power)*VH';
    
    delta_temp = delta;
    obj_temp = obj;
    obj = real(log2((det(LD + H'*S*H))/det(LD)));
    if (i>=1)
        delta = abs(obj-obj_temp);
        if(i<=length(del)-1)
            del(i) = delta;
        end
    end
    
    %solve minimization problem
    Phi = LD + H'*S*H;
    A = diag(diag(LD).^(-1/2));
    B = diag(diag(diag(diag(SH*diag(power)*SH').^-1) + eye(n)).^-1);
    IPhi = diag(diag(A*(eye(n)-UH*B*UH')*A));
    %newton method
    delt = 1;
    gamma0 = 0.01;
    gamma = gamma0;
    while(delt > eps)
        gamma0 = gamma;
        temp = real((diag(IPhi)'./diag(P)' + gamma0));
        fx = real(sum(1./temp) - sum(diag(P)'));
        temp = (diag(IPhi)'./diag(P)' + gamma0).^2;
        fdx = -real(sum(1./temp));
        gamma = gamma - fx/fdx;
        delt = abs(gamma-gamma0);
    end
    
    
    LD_temp = LD;
    LD = real(diag(1./(diag(IPhi)'+ gamma*diag(P)')));
    
    
    %break in case exceeding the limit
    if (i >= ilim)
        break;
    end
    
    i = i + 1;
    
end

[UH, SH, VH] = svd(H*diag(diag(LD).^(-1/2)), 'econ');
Q = diag(diag(LD).^(-1/2))*VH*UH'*S*UH*VH'*diag(diag(LD).^(-1/2));

Q_found = Q;
N_iter = i;
D_gap = del;

end


function [PW IG0] = wf(P, H)
P = sum(diag(P)');
sigma2 = 1;
ig0 = 0;
[U, eigH, V] = svd(H);
eigH = diag(eigH);
rH = rank(H);
power = zeros(1, rH);
igamma = sigma2./(abs(eigH).^2);
temp = 0;

for k = rH:-1:1
    temp = (P+sum(1./abs(eigH(1:k)).^2)*sigma2)/k;
    if ((temp-igamma(k))>0)
        break;
    end
end

PW = max(temp-igamma,0)';
IG0 = temp;
end
