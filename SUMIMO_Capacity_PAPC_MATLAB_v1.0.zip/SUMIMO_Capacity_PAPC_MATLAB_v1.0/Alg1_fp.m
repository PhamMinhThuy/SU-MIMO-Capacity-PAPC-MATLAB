function [Q_found, N_iter, D_gap] = Alg1_fp(H, P, eps, ilim)

%initialization
i = 0;
delta = 1 + eps;
[m, n] = size(H);
[UH, SH, VH] = svd(H);
[ma, na] = size(SH);
SH(SH<0) = 0;
Sv = SH(SH>0).^(-2);
Svs = 1-Sv;
Svs(Svs <0) = 0;
if(length(Svs)<na)
    Svs = [Svs;zeros(na-length(Svs),1)];
end
Phi = VH*diag(1-Svs)*VH';
lamda0 = P*diag(diag((eye(n) - diag(diag(Phi))).^(-1)));
lamda = lamda0;
LD = diag(diag(lamda).^(-1)) ;
del = zeros(1, ilim);
Q = zeros(n, m);
Phi = eye(n);
alpha = 0;

while(delta > eps)
    
    %performing fixed waterfilling
    [Q R] = qr(H);
    [UH SH VH] = svd(R*diag(diag(LD).^(-1/2)));
    UH = Q*UH;
    SH(SH<0) = 0;
    Sv = SH(SH>0).^(-2);
    Svs = 1-Sv;
    Svs(Svs <0) = 0;
    if(length(Svs)<na)
        Svs = [Svs;zeros(na-length(Svs),1)];
    end
    Phi_temp = Phi;
    Phi = VH*diag(1-Svs)*VH';
    lamda_temp = lamda;
    Q = diag(diag(LD).^(-1/2))*VH*diag(Svs)*VH'*diag(diag(LD).^(-1/2));
    
    %updating lamda
    lamda = real(alpha*lamda + (1-alpha)*(P + diag(diag(Phi))*lamda));
    LD = diag(diag(lamda).^(-1));
    delta_temp = delta;
    delta = abs(trace((diag(diag(lamda_temp).^(-1)))*(Q-P)));
    
    if(i<=length(del)-1)
        del(i+1) = delta;
    end
    
    %break in case exceeding the limit
    if (i >= ilim)
        break;
    end
    
    
    i = i + 1;
    
    
end

Q_found = Q;
N_iter = i;
D_gap = del;


end